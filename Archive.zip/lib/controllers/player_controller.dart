import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:owl_player/layouts/player_layout.dart';
import 'package:video_player/video_player.dart';
import 'package:window_manager/window_manager.dart';

class PlayerController extends GetxController {
  late VideoPlayerController playerController;

  late Timer timer;

  double lastVolume = 1;

  bool isPickFile = false;
  bool isGuiVisible = false;
  bool isFullscreen = false;

  @override
  void onInit() {
    const platform = MethodChannel('fileChannel');

    platform.setMethodCallHandler((call) async {
      if (call.method == 'loadFile') {
        String filePath = call.arguments;
        await loadFile(filePath);
      }
    });

    super.onInit();
  }

  @override
  void onClose() {
    playerController.dispose();
    super.onClose();
  }

  void pickFile() {
    if (isPickFile == false) {
      isPickFile = true;
      FilePicker.platform.pickFiles(allowMultiple: false, type: FileType.video, lockParentWindow: true).then((value) {
        if (value != null) {
          loadFile(value.files.single.path!);
        }
        isPickFile = false;
      });
    }
  }

  Future<void> loadFile(String path) async {
    try {
      await playerController.dispose();
    } catch (e) {
      // print(e);
    } finally {
      playerController = VideoPlayerController.file(File(path));
      await playerController.initialize();
      playerController.play();
      await adjustWindowSizeWithAspectRatio(playerController.value.aspectRatio);
      update([PlayerLayout.id]);
    }
  }

  Future<void> adjustWindowSizeWithAspectRatio(double aspectRatio) async {
    Size currentSize = await windowManager.getSize();

    double newHeight = currentSize.width / aspectRatio;

    if (newHeight < 450) {
      newHeight = 450;

      double newWidth = newHeight * aspectRatio;

      await windowManager.setSize(Size(newWidth, newHeight));
    } else {
      await windowManager.setSize(Size(currentSize.width, newHeight));
    }
  }

  Future<void> onChangeFullscreen() async {
    isFullscreen = !(await windowManager.isFullScreen());
    windowManager.setFullScreen(isFullscreen);
    update([PlayerLayout.id]);
  }

  Future<void> onChangeStatus() async {
    playerController.value.isPlaying ? await playerController.pause() : await playerController.play();
    update([PlayerLayout.id]);
  }

  Future<void> onForward() async {
    playerController.seekTo((await playerController.position)! + Duration(seconds: 10));
    update([PlayerLayout.id]);
  }

  Future<void> onBackward() async {
    playerController.seekTo((await playerController.position)! - Duration(seconds: 10));
    update([PlayerLayout.id]);
  }

  Future<void> onIncVolume() async {
    playerController.setVolume(clampDouble(playerController.value.volume + 0.1, 0, 1));
    lastVolume = playerController.value.volume;
    update([PlayerLayout.id]);
  }

  Future<void> onDecVolume() async {
    playerController.setVolume(clampDouble(playerController.value.volume - 0.1, 0, 1));
    lastVolume = playerController.value.volume;
    update([PlayerLayout.id]);
  }
}
